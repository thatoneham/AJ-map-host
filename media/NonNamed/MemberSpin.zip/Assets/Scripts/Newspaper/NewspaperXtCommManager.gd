extends Node

var _seenCallback:Callable

func sendSetPageSeenRequest(param1:int, param2:Callable = Callable()):
	_seenCallback = param2;
	Global.gMainFrame.server.setXtObject_Str("nps",[param1]);
	

func handleXtReply(param1:SFEvent):
	if !param1.status:
		DebugUtility.debugTrace("ERROR: NewspaperXtCommManager handleXtReply was called with bad evt.status:" +  str(param1.status));
		return
	var _loc2_:Array = param1.obj;
	var _loc3_ = _loc2_[0]
	if "nps" == _loc3_:
		NewspaperManager.updateNewspaperData(_loc2_[2],_loc2_[3])
		if _seenCallback.is_valid():
			_seenCallback.call(_loc2_[2],_loc2_[3]);
			_seenCallback = Callable();
