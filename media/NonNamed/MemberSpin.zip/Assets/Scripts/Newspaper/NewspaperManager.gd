extends Node

var _hasSeenFirstPage:bool;

var _hasUnseenPages:bool;

var _newspaperDefs:NewspaperDefCollection;

var _newspaperData:NewspaperDataCollection;

var _newspaperPopup#:NewspaperPopup;

var _newspaperCloseCallback:Callable;

func loadNewspaperDefs(param1:Callable) -> void:
	var _loc2_:DefPacksDefHelper = null;
	_hasSeenFirstPage = true
	if _newspaperDefs != null:
		param1.call(_newspaperDefs)
	else:
		_loc2_ = DefPacksDefHelper.new();
		_loc2_.init("1065",onDefsLoaded,param1,2);
		DefPacksDefHelper.mediaArray[1065] = _loc2_;
	
func setNewspaperData(param1:NewspaperDataCollection) -> void:
	_newspaperData = param1;
	checkIfNewPagesExist();

func onDefsLoaded(param1:DefPacksDefHelper):
	DefPacksDefHelper.mediaArray[1065] = null;
	_newspaperDefs = NewspaperDefCollection.new();
	for _loc2_ in param1.def:
		_newspaperDefs.setNewspaperDefItem(_loc2_.id,NewspaperDef.new(_loc2_.id,_loc2_.name,_loc2_.pageMediaRefId,_loc2_.iconMediaRefId,_loc2_.giftType,_loc2_.giftRefId,_loc2_.amount,_loc2_.country,int(_loc2_.availabilityStartTime),int(_loc2_.availabilityEndTime),int(_loc2_.membersOnly)));
	
	if param1.passback && param1.passback.is_valid():
		param1.passback.call(_newspaperDefs);
	
	
var hasUnseenPages:int:
	get:
		return _hasUnseenPages
	set(param1):
		_hasUnseenPages = param1

var hasSeenFirstPage:bool:
	get:
		return _hasSeenFirstPage
	set(param1):
		_hasSeenFirstPage = param1
		
func getNewspaperDef(param1:int) -> NewspaperDef:
	return _newspaperDefs.getNewspaperDefItem(param1);

func getNewspaperData(param1:int) -> NewspaperData:
	return _newspaperData.getNewspaperDataItem(param1);

func updateNewspaperData(param1:int,param2:int) -> void:
	var _loc3_:NewspaperData = null
	if param2 != -1:
		_loc3_ = _newspaperData.getNewspaperDataItem(param1);
		if _loc3_:
			_loc3_.timeSeen = param2
		else:
			_loc3_ = NewspaperData.new({
				"defId":param1,
				"ts":param2
			});
		_newspaperData.setNewspaperDataItem(param1,_loc3_);


func openNewspaperPopup(param1:Callable) -> void:
	_newspaperCloseCallback = param1;
	print("open news paper boi")
	#_newspaperPopup = NewspaperPopup.new(onNewspaperClose);

func onNewspaperClose():
	_newspaperPopup = null;
	if _newspaperCloseCallback.is_valid():
		_newspaperCloseCallback.call()
		_newspaperCloseCallback = Callable()

func checkIfNewPagesExist():
	loadNewspaperDefs(onNewspaperDefsLoaded)
	
func onNewspaperDefsLoaded(param1:NewspaperDefCollection) -> void:
	GenericListXtCommManager.requestGenericList(627,onListLoaded);

func onListLoaded(param1:int, param2:Array, param3:Dictionary) -> void:
	onItemListFiltered(param2)
func onItemListFiltered(param1:Array) -> void:
	var _loc2_:NewspaperDef = null;
	var _loc4_:int = 0;
	var _loc5_:int = 0;
	var _loc6_:NewspaperDefCollection = NewspaperDefCollection.new();
	_loc4_ = 0;
	while _loc4_ < param1.size():
		_loc2_ = getNewspaperDef(param1[_loc4_]);
		if _loc2_ && (_loc2_.country == "" || _loc2_.country.find(Global.gMainFrame.clientInfo.countryCode) != -1) && _loc2_.getIsViewable(Global.gMainFrame.userInfo.isMember):
			_loc6_.pushNewspaperDefItem(_loc2_);
		_loc4_ += 1
	GenericListXtCommManager.filterTypedItems(_loc6_);
	hasSeenFirstPage = true;
	
	var _loc7_:int = int(Global.gMainFrame.userInfo.userVarCache.getUserVarValueById(455));
	
	if _loc7_ == -1:
		hasSeenFirstPage = false;
		hasUnseenPages = true;
	else:
		_loc5_ = 0;
		while _loc5_ < _loc6_.size():
			if _loc7_ < _loc6_.getNewspaperDefItem(_loc5_).availabilityStartTime:
				if _loc5_ == 0:
					hasSeenFirstPage = false;
				hasUnseenPages = true
				break
			_loc5_ += 1
