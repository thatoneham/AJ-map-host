extends Node

var transition_scene_path := "res://Assets/Tscn/DiamondTransitionEffect.tscn"
var scene = null
var tween = null
var layer = null
var transition = null
static var has_loaded_pck = false
func initTransition(_scene):
	scene = _scene

	transition = load(transition_scene_path).instantiate()
	layer = CanvasLayer.new()
	layer.layer = 100

	layer.add_child(transition)
	get_tree().root.add_child(layer)
	transition.get_node("Globe")
	tween = create_tween()
	var transitionmat = transition.material
	tween.tween_property(transitionmat, "shader_parameter/progress", 1.0, 2.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.finished.connect(Callable(self, "startAssetLoad"))

func startAssetLoad():
	var is_editor = OS.has_feature("editor")
	if !has_loaded_pck && false:#!is_editor:
		ResourceStack.start(finishTransition)
	else:
		Utils.loadAudio()
		DarkenManager.init()
		EmoticonUtility.preload_emojis()
		finishTransition()
		
func finishTransition():
	tween.finished.disconnect(Callable(self, "finishTransition"))

	get_tree().change_scene_to_file(scene)
	has_loaded_pck = true
	
func hideFade():
	var transitionmat = transition.material
	var tween2 = create_tween()
	tween2.tween_property(transitionmat, "shader_parameter/progress", 0.0, 2.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween2.finished.connect(Callable(self, "destroy"))

func destroy():
	transition.queue_free()
	layer.queue_free()
